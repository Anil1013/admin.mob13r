import React from 'react';

export default function Navbar() {
  return (
    <nav style={{ backgroundColor: '#800000', padding: '10px', color: 'white' }}>
      <h2>Mob13r Admin Panel</h2>
    </nav>
  );
}
